const ex = require('express');
const ws = require('ws');
const pt = require('path');

const ap = ex();
const pr = process.env.PORT || 3000;

ap.use(ex.static(pt.join(__dirname, '../public')));

ap.get('/', (rq, rs) => rs.sendFile(pt.join(__dirname, '../public/index.html')));
ap.get('/room/:id', (rq, rs) => rs.sendFile(pt.join(__dirname, '../public/index.html')));

const sv = ap.listen(pr, () => console.log(`Сервер запущен: ${pr}`));

const wss = new ws.Server({ server: sv });

wss.on('connection', (ws) => {
  ws.on('message', (m) => {
    wss.clients.forEach(c => {
      if (c !== ws && c.readyState === ws.OPEN) c.send(m);
    });
  });
});
