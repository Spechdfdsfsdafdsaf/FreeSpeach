document.addEventListener('DOMContentLoaded', () => {
  const hp = document.getElementById('home-page');
  const rp = document.getElementById('room-page');
  const jb = document.getElementById('join-btn');
  const cb = document.getElementById('create-btn');
  const rc = document.getElementById('room-code');
  const tc = document.getElementById('toggle-chat');
  const cs = document.getElementById('chat-sidebar');
  const cc = document.getElementById('close-chat');
  const lb = document.getElementById('leave-room');
  const lm = document.getElementById('leave-modal');
  const cl = document.getElementById('confirm-leave');
  const ca = document.getElementById('cancel-leave');
  const mi = document.getElementById('message-input');
  const sm = document.getElementById('send-message');
  const cm = document.getElementById('chat-messages');

  function gc() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }

  function er(c) {
    document.getElementById('room-id-display').textContent = `Комната: #${c}`;
    hp.classList.remove('active');
    rp.classList.add('active');
    history.pushState({}, '', `/room/${c}`);
  }

  cb.addEventListener('click', () => er(gc()));
  
  jb.addEventListener('click', () => {
    const c = rc.value.trim();
    c.length >= 4 ? er(c) : alert('Минимум 4 символа');
  });

  tc.addEventListener('click', () => cs.classList.toggle('active'));
  cc.addEventListener('click', () => cs.classList.remove('active'));
  
  lb.addEventListener('click', () => lm.style.display = 'block');
  cl.addEventListener('click', () => window.location.href = '/');
  ca.addEventListener('click', () => lm.style.display = 'none');

  sm.addEventListener('click', () => {
    const m = mi.value.trim();
    if (m) {
      const msg = document.createElement('div');
      msg.className = 'chat-message';
      msg.textContent = m;
      cm.appendChild(msg);
      mi.value = '';
      cm.scrollTop = cm.scrollHeight;
    }
  });

  mi.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sm.click();
  });
});
