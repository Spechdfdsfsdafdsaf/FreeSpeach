let ls;
let pc = {};
const ws = new WebSocket(`ws://${window.location.hostname}:3000`);

async function im() {
  try {
    ls = await navigator.mediaDevices.getUserMedia({video: true, audio: true});
    const lv = document.createElement('video');
    lv.srcObject = ls;
    lv.autoplay = true;
    lv.muted = true;
    av(lv, 'Вы (аноним)');
  } catch (e) {
    console.error('Ошибка медиа:', e);
  }
}

function av(v, u) {
  const vc = document.createElement('div');
  vc.className = 'video-container';
  
  const ui = document.createElement('div');
  ui.className = 'user-info';
  
  const a = document.createElement('div');
  a.className = 'user-avatar';
  a.textContent = u.charAt(0).toUpperCase();
  
  const n = document.createElement('span');
  n.textContent = u;
  
  ui.appendChild(a);
  ui.appendChild(n);
  vc.appendChild(v);
  vc.appendChild(ui);
  document.getElementById('video-grid').appendChild(vc);
}

ws.onmessage = (e) => {
  const d = JSON.parse(e.data);
  switch (d.type) {
    case 'offer': ho(d); break;
    case 'answer': ha(d); break;
    case 'candidate': hc(d); break;
    case 'user-joined': uj(d.id); break;
    case 'user-left': ul(d.id); break;
  }
};

window.onload = im();
